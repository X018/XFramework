extern "C" {
#include "../../../WebGLPlugins/lpcap.c"
#include "../../../WebGLPlugins/lpcode.c"
#include "../../../WebGLPlugins/lpprint.c"
#include "../../../WebGLPlugins/lptree.c"
#include "../../../WebGLPlugins/lpvm.c"
}
